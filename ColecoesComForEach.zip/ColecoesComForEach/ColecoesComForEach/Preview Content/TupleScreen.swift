//
//  TupleScreen.swift
//  ColecoesComForEach
//
//  Created by User on 19/09/23.
//

import SwiftUI

struct TupleScreen: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct TupleScreen_Previews: PreviewProvider {
    static var previews: some View {
        TupleScreen()
    }
}

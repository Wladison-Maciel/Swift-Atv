//
//  setScreen.swift
//  ColecoesComForEach
//
//  Created by User on 19/09/23.
//

import SwiftUI

struct setScreen: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct setScreen_Previews: PreviewProvider {
    static var previews: some View {
        setScreen()
    }
}

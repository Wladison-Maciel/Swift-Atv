import SwiftUI

struct ErroCenário{
    let emoji: String
    let errorMensage: String
    let id = UUID()
    // ID auto incremento
}

struct ArrayScreen: View {
    let erroCenarios: [ErroCenário] = [
        ErroCenário(emoji: "😫", errorMensage: "Error: Variável não foi incializada. Tente iniciar com um valor"),
        ErroCenário(emoji: "☹️", errorMensage: "Erro: O íncidce está fora dos limites da matriz. Provavelmente você contou até 11 ao invés de 10"),
        ErroCenário(emoji: "😤", errorMensage: "Erro: Chaves não correspondentes. Lembre-se, abra chaves '{' precisa ter um fecha chaves '}'"),
        ErroCenário(emoji: "😰", errorMensage: "Erro: Esqueceu de fechar as apas, lembre-se de fechar para não ficar confuso"),
        ErroCenário(emoji: "😣", errorMensage: "Erro: Divisãom por zero. Não é possível dividr nada por zero, mesmo na programação"),
        ErroCenário(emoji: "😈", errorMensage: "Você está preso um um loop que nunca termina, seus personagens virtuais podem ficar tontos"),
    ]
    // Conjunto de Arrays com String
    
    var body: some View {
        ScrollView {
            // Deslizar a tela
            VStack (spacing: 10){
                ForEach(erroCenarios, id: \.id) {
                    // Onde vai buscar as informações do texto
                    erroCenario in
                    Text(erroCenario.emoji)
                        .font(.system(size: 50))
                        .foregroundColor(.white)
                        .background(Color.red)
                        .clipShape(Circle())
                    // Configuração do Emoji
                    Text(erroCenario.errorMensage)
                        .font(.headline)
                        .multilineTextAlignment(.center)
                        .padding()
                    // Configuração da mensagem de erro
                }
            }
            .frame(maxWidth: .infinity, minHeight: 150)
            .background(Color.white)
            .cornerRadius(15)
            .shadow(color: Color.gray.opacity(0.6), radius: 5, x: 0, y: 2)
        .padding(.init(top: 5, leading: 16, bottom: 5, trailing: 16))
            // Configuração da VStack
        }
    }
}

struct ArrayScreen_Previews: PreviewProvider {
    static var previews: some View {
        ArrayScreen()
    }
}

//
//  ColecoesComForEachApp.swift
//  ColecoesComForEach
//
//  Created by User on 19/09/23.
//

import SwiftUI

@main
struct ColecoesComForEachApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
